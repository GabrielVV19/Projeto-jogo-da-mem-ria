
package jogomemoria;
import telas.TelaPrincipal;
public class JogoMemoria {
    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
    }
    
}
