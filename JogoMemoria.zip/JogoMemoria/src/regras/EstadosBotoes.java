
package regras;
public enum EstadosBotoes {
    NORMAL,SELECIONADO,PARES_ENCONTRADOS;
}
